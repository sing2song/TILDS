package example3;

public class Start {
	public static void exam1() {
		MyHash hs = new MyHash(10);
		int value = 0;
		for(int i=0; i<1000; i++) {
			value = (int)(Math.random()*100) + 1;
			hs.Insert(value);
			//hs.PrintAll();
		}
		
		hs.PrintAll();
		
		//�˻�
		Object obj = hs.Select(value);
		if(obj == null) {
			System.out.println("����.");
		}
		else
			System.out.println("�˻���� : " + (int)obj);
	}
	
	public static void main(String[] args) {
		exam1();
	}
}
