package example3;

public class MyHash {
	//�ɹ� �ʵ�
	private MyDList[] arr;	//
	private int max;		//������ �ִ� ũ��[Overflow ���� �˻�]
	private int size;		//���� ����� ����
	
	//������
	public MyHash(int max) {
		this.max = max;
		this.size = 0;
				
		arr = new MyDList[max];				//�迭 ����
		for(int i=0; i< arr.length; i++)
			arr[i] = new MyDList();			//�� �迭�� ��������� ���Ḯ��Ʈ�� ����
	}
	
	//get & set �޼���
	public Object getData(int idx) {
		
		return null;
		//return arr[idx];
	}
	
	private boolean IsOverflow() {
		return false;
	}
	
	private boolean IsUniq(Object key) {
		for(int i=0; i<arr.length; i++) {
			MyDList list = arr[i];
			MyDList.DNode node = list.Select(key);
			if(node != null)
				return false;				
		}
		return true;
	}
	
	public boolean Insert(Object key) {
		if(IsUniq(key) == false)
			return false;
		
		if(IsOverflow() == true)
			return false;
		
		int hvalue = HashFunction(key);		
		
		MyDList list = arr[hvalue];
		list.push_front(key);
		size++;
		
		return true;
	}
	
	public Object Select(Object key) {
		int hvalue = HashFunction(key);
		MyDList list = arr[hvalue];
		MyDList.DNode node = list.Select(key);
		if(node != null)
			return node.data;			
		return null;
	}
	
	
	public boolean Delete(Object key) {
		int hvalue = HashFunction(key);
		MyDList list = arr[hvalue];
		MyDList.DNode node = list.Select(key);
		if(node != null) {
			list.erase_random(node);
			return true;
		}
		else
			return false;
	}
	
	public void Clear() {
		this.size = 0;
		
		for(int i=0; i< arr.length; i++) {
			MyDList list = arr[i];
			list.Clear();
		}		
	}
	
	public void PrintAll() {
		System.out.println("���尳�� : " + size);
		System.out.println("\n--------------------------------------------------------------------------------------");
		for(int i=0; i< arr.length; i++) {
			System.out.print("[" + i + "]" );
			MyDList list = arr[i];
			list.Select_PrevAll();
			System.out.println();
		}
		System.out.println("\n--------------------------------------------------------------------------------------");
	}
	
	//�ؽ� �Լ�
	private int HashFunction(Object key) {	
		return ((int)key % max);
	}	
}
